/**
 * Created by enihsyou on 16/3/3.
 */
public class Work_01 {
    public static void main(String[]args){
        System.out.print("programming is cool");
        System.out.println();
        System.out.print("It makes me think!");
        System.out.println();
        System.out.print("学号: 1517440121");
        System.out.println();
        System.out.print("姓名: 黄春翔");
        System.out.println();
    }
}
