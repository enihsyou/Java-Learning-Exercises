//package test3;

public abstract class test3 {

    public static void main(String[] args) {
        float r = 98678.18f;
        r = r + 0.000001f;
        System.out.println("r=" + r);
    }
}

